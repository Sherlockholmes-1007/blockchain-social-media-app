const GenSea = artifacts.require("GenSea");

module.exports = function(deployer) {
  deployer.deploy(GenSea);
};